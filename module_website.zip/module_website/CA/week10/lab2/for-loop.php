<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>PHP for loop</title>
  </head>
  <body>

    <?php
	  for ($i = 0; $i < 5; $i++) {
		echo nl2br("Number: ". ($i+1) ."\n");
      } 
	?>

  </body>
</html>
